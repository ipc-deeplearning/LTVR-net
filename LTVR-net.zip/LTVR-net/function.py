import cv2
import numpy as np
import torch
from torch import nn
import matplotlib.pyplot as plt
plt.rc("font", family='Microsoft YaHei')
from PIL import Image

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def csv_name(sample_name, strategy):
    # [         A          ,         B          ,         C          ,         D          ,]
    # A:Net                  # B:loss            # C:diff_distance         # D:learning_rate
    # 0:Unet                 # 0:PhysenNet
                              # 1:L1
                              # 2:L2
                              # 3:Lp

    Net_list = ['Unet']
    net = Net_list[strategy[0]]

    loss_list = ['PhysenNet', 'L1', 'L2', 'LP']
    TV = loss_list[strategy[1]]

    log_name = '/' + str(strategy[2]) + '_' + net + '_' + TV + '_' + sample_name + '_' + str(strategy[3]) + '.csv'   #文本名称

    return log_name


def _fresnel_dfft(inpt_amplitude, inpt_phase, wavelength, dim, pixelsize, distance):

    inpt = inpt_amplitude*torch.exp(1j * inpt_phase)

    # wave number k
    wave_num = 2*torch.pi / wavelength

    # the axis in frequency space
    xstart = pixelsize * dim/2
    xend = pixelsize * -(dim/2)
    x = torch.linspace(0.25/xstart, 0.25/xend, dim)
    qx = x * dim
    mesh_qx, mesh_qy = torch.meshgrid(qx, qx)

    # the propagation function
    impulse_q = np.exp(
        (1j * wave_num * distance) *
        (1 - wavelength**2 * (mesh_qx**2 + mesh_qy**2))/2
        )

    inpt.to(device)
    impulse_q.to(device)

    part1 = torch.fft.fft2(inpt).to(device)
    part2 = torch.fft.ifftshift(impulse_q).to(device)

    diffraction = torch.fft.ifft2(part1 * part2)
    intensity = torch.abs(diffraction) * torch.abs(diffraction)
    # norm
    intensity = intensity / torch.max(intensity)

    return intensity

#  save_result
def estimated_diff_pretreatment(measured_y):
    estimated_diff = np.abs(measured_y.to("cpu").detach().numpy())
    estimated_diff = (estimated_diff * 255).astype(np.uint8)
    diff_img = Image.fromarray(estimated_diff)
    return diff_img
def estimated_amplitude_pretreatment(pred_y):
    estimated_amplitude = pred_y.to("cpu").detach().numpy()[0, 0, :, :]
    estimated_amplitude = ((estimated_amplitude - np.min(estimated_amplitude)) * 255).astype(np.uint8)
    amplitude_img = Image.fromarray(estimated_amplitude)
    return amplitude_img
def estimated_phase_pretreatment(pred_y):
    estimated_phase = pred_y.to("cpu").detach().numpy()[0, 1, :, :]
    estimated_phase = estimated_phase - np.min(estimated_phase)
    estimated_phase = (estimated_phase * 255 / np.pi).astype(np.uint8)
    phase_img = Image.fromarray(estimated_phase)
    return phase_img
def phase_txt(pred_y):
    estimated_phase = pred_y.to("cpu").detach().numpy()[0, 1, :, :]
    return estimated_phase