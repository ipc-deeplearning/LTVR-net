#-----------------------------------------------------------------------------#
import os
import numpy as np
import csv
import matplotlib.pyplot as plt
plt.rc("font", family='Microsoft YaHei')
import torch
from PIL import Image
from function import _fresnel_dfft
from function import *
from data_loader import *
from loss_function import *
from basic_Unet import basic_model


#------------------------------------------------------------------------------
# device
torch.manual_seed(1)
print(torch.__version__)
current_dir = os.getcwd()
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

#------------------------------------------------------------------------------
save_path = './result'
sample_name = 'USAF-1.07mm'

# The weight of the segmented loss: MSE/MS_SSIM/LPTV   /change_step
weight = [2,1,0.01,0]

strategy = [0, 3, 1.07, 0.01]
# [         A          ,         B          ,         C          ,         D          ,]
# A:Net                  # B:loss            # C:diff_distance         # D:learning_rate
# 0:Unet                 # 0:PhysenNet
                         # 1:L1
                         # 2:L2
                         # 3:Lp

log_name = csv_name(sample_name, strategy)
diff_name = './dataset/' + sample_name + '.png'

#------------------------------------------------------------------------------
shape = [256, 256]
diff = diff_pretreatment(diff_name)

if __name__ == "__main__":

    #---------------------------------------------------------
    data = sample_dataset(diff, "training", count = 20000, batch_size = 1, noise_level = 0)
    train_data = torch.utils.data.DataLoader(data, batch_size = 2000, shuffle = True)
    target = torch.tensor(diff).to(device)
    #---------------------------------------------------------
    if strategy[0] == 0:
        net = basic_model().to(device)
    #---------------------------------------------------------
    mse = nn.MSELoss()
    L1TV = L1_Total_Variation()
    L2TV = L2_Total_Variation()
    LPTV = LP_Total_Variation()
    lr = strategy[3]
    optimizer = torch.optim.Adam([{'params': net.parameters()}], lr=lr)
    step = 0

    for train_iter in train_data:

        for feature in train_iter:

            step += 1
            feature = feature.to(device)
            pred_y = net(feature)

            # -------------------------------------------------
            measured_y = _fresnel_dfft(
                pred_y[0, 0, :, :], pred_y[0, 1, :, :], 632.8e-6, 256, 1.85e-3, strategy[2])
            focus_complex_amplitude = pred_y[0, 0, :, :] * torch.exp(1j * pred_y[0, 1, :, :])

            # loss
            mse_loss = mse(measured_y.float(), target.float())
            ms_ssim_loss = msssim(measured_y.float(), target.float())
            TV_loss1 = L1TV(focus_complex_amplitude)
            TV_loss2 = L2TV(focus_complex_amplitude)
            TV_lossp = LPTV(focus_complex_amplitude)
            # optimize
            if strategy[0] == 0:
                hybird_loss = Hybird_Loss(mse_loss, ms_ssim_loss, TV_loss1, TV_loss2, TV_lossp, weight, step, strategy)
                print('step = ', step, ' ms_ssim = {:.7f}'.format(ms_ssim_loss), ' mse = {:.7f}'.format(mse_loss),
                      ' LpTV1 = {:.7f}'.format(TV_lossp))
                optimizer.zero_grad()
                hybird_loss.backward()
                optimizer.step()

            if step % 100 == 0:
                diff_img = estimated_diff_pretreatment(measured_y)
                plt.imsave(save_path + '/pre_diff/' + '%d.png' % step, diff_img, cmap='gray')

                amplitude_img = estimated_amplitude_pretreatment(pred_y)
                plt.imsave(save_path + '/pre_amplitude/' + '%d.png' % step, amplitude_img, cmap='gray')

                phase_img = estimated_phase_pretreatment(pred_y)
                plt.imsave(save_path + '/phase_image/' + '%d.png' % step, phase_img, cmap='gray')

                phase_csv = phase_txt(pred_y)
                np.savetxt(save_path + '/pre_phase/'+ str(step) + '.csv', phase_csv, delimiter=',')

            # log
            with open(save_path + log_name, 'a', newline='') as wr:
                csv_writer = csv.writer(wr)
                csv_writer.writerows([[step,  mse_loss.item(),  ms_ssim_loss.item(),  TV_loss1.item(),  TV_loss2.item(),  TV_lossp.item()]])