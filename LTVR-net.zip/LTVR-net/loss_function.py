import torch
from torch import nn
from pytorch_msssim import ssim, ms_ssim, SSIM, MS_SSIM
import torchvision.transforms as transforms
import torch.nn.functional as F
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# MSE and MS_SSIM
mse = nn.MSELoss()
def msssim(X,Y):
    ms_ssim = MS_SSIM(win_size=11, win_sigma=1.5, data_range=1, size_average=True, channel=1)
    X = X.unsqueeze(0).unsqueeze(0)
    Y = Y.unsqueeze(0).unsqueeze(0)
    msssim_loss = 1 - ms_ssim(X, Y)
    return msssim_loss
# L1
class L1_Total_Variation(nn.Module):
    def __init__(self, weight: float = 1) -> None:

        super().__init__()
        self.weight = weight

    def forward(self, x):
        dimension = len(x.shape)
        if dimension == 2:
            batch_size, c = 1, 1
            h, w = x.size()
            tv_h = torch.abs(x[1, :] - x[-1, :]).sum()
            tv_w = torch.abs(x[:, 1] - x[:, -1]).sum()
        else:
            batch_size, c, h, w = x.size()
            tv_h = torch.abs(x[:, :, 1:, :] - x[:, :, :-1, :]).sum()
            tv_w = torch.abs(x[:, :, :, 1:] - x[:, :, :, :-1]).sum()

        return self.weight * (tv_h + tv_w) / (batch_size * c * h * w)
# L2
class L2_Total_Variation(nn.Module):
    def __init__(self, weight: float = 1) -> None:

        super().__init__()
        self.weight = weight

    def forward(self, x):
        dimension = len(x.shape)
        if dimension == 2:
            batch_size, c = 1, 1
            h, w = x.size()
            tv_h = torch.abs(x[1, :] - x[-1, :]).sum()
            tv_w = torch.abs(x[:, 1] - x[:, -1]).sum()
        else:
            batch_size, c, h, w = x.size()
            tv_h = torch.pow((x[:, :, 1:, :] - x[:, :, :-1, :]), 2).sum()
            tv_w = torch.pow((x[:, :, :, 1:] - x[:, :, :, :-1]), 2).sum()

        return self.weight * (tv_h + tv_w) / (batch_size * c * h * w)
# Lp
class LP_Total_Variation(nn.Module):
    def __init__(self, weight: float = 1) -> None:

        super().__init__()
        self.weight = weight

    def forward(self, x):

        gauss = transforms.GaussianBlur(kernel_size=3, sigma=(0.2, 0.2))
        dimension = len(x.shape)
        if dimension == 2:
            x = x.unsqueeze(0).unsqueeze(0)
        batch_size, c, h, w = x.size()
        Gx = gauss(x)
        weight_ph = 1 + (1 / (1 + torch.pow(torch.abs(Gx[:, :, 1:, :] - Gx[:, :, :-1, :]), 2)))
        weight_pw = 1 + (1 / (1 + torch.pow(torch.abs(Gx[:, :, :, 1:] - Gx[:, :, :, :-1]), 2)))

        tv_h = torch.abs(x[:, :, 1:, :] - x[:, :, :-1, :])
        tv_w = torch.abs(x[:, :, :, 1:] - x[:, :, :, :-1])

        tv_h = ((tv_h ** weight_ph) / weight_ph).sum()
        tv_w = ((tv_w ** weight_pw) / weight_pw).sum()


        return self.weight * (tv_h + tv_w) / (batch_size * c * h * w)

# Sectional mixing loss
def Hybird_Loss(mse, msssim, L1TV, L2TV, LpTV, weight, step, strategy):

    if strategy[1] == 0:
        hybird_loss = mse
    else:
        indirect_loss = mse * weight[0] + msssim * weight[1]

        if strategy[1] == 1:
            direct_loss = L1TV
        if strategy[1] == 2:
            direct_loss = L2TV
        if strategy[1] == 3:
            direct_loss = LpTV

        if weight[3] == 0:
            hybird_loss = indirect_loss + direct_loss * weight[2]
        else:
            if step <= weight[3]:
                hybird_loss = indirect_loss + direct_loss * 0
            else:
                hybird_loss = indirect_loss + direct_loss * weight[2]

    return hybird_loss