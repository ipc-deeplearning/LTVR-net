import torch
import numpy as np
import matplotlib.pyplot as plt


def diff_pretreatment(input_path):
    diffraction = np.array(plt.imread(input_path))
    diffraction = diffraction / np.max(diffraction)
    return diffraction

# Dataset
class sample_dataset(torch.utils.data.Dataset):

    def __init__(
            self, sample, list_ID, count, batch_size, noise_level
    ):
        self.sample = np.array(sample)
        self.list_ID = list_ID
        self.noise_level = noise_level
        self.shape = np.shape(self.sample)
        self.count = count
        self.batch_size = batch_size

    def __len__(self):
        return self.count

    def __getitem__(self, index):
        noise = np.random.uniform(0, self.noise_level, size=self.shape)
        input = np.reshape(
            np.array(self.sample + noise),
            (self.batch_size, 1, self.shape[0], self.shape[1])
        )
        input = torch.tensor(input).float()

        return input